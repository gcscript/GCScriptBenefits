﻿using GCScript.DataBase.Models;
using GCScript.DataBase.ViewModels;
using MongoDB.Bson;
using MongoDB.Driver;

namespace GCScript.DataBase.Controllers;

public class DataMenuController
{
    private readonly IMongoCollection<MDataMenu> _dataMenuCollection;
    public DataMenuController()
    {
        var mongoClient = new MongoClient(Settings.MongoDbConnectionString);
        var mongoDatabase = mongoClient.GetDatabase(Settings.MongoDbDatabase);
        _dataMenuCollection = mongoDatabase.GetCollection<MDataMenu>("DataMenu");
    }

    public async Task<List<VMDataMenu>> GetAllAsync()
    {
        var list =  await _dataMenuCollection.Find(new BsonDocument()).ToListAsync();
        return list.Select(x => new VMDataMenu
        {
            UF = x.UF,
            Operator = x.Operator,
            Company = x.Company,
            Unit = x.Unit,
            UnitId = x.UnitId.ToString()
        }).ToList();
    }
}
